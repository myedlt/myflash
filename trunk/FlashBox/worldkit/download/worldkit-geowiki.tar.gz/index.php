<html>
<head>
<title>worldKit geowiki</title>
<link rel="stylesheet" type="text/css" href="geowiki.css">
<script language="javascript" src="jsrsClient.js"></script>
<script language="javascript" src="geowiki.js"></script>
</head>
<body onLoad="loadActions()">

<table><tr><td valign="top">

<span class="headline"><nobr>worldKit geowiki</nobr> </span><p/>

<object id="worldkit" height="350" width="700" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=8,0,0,0" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000">
<param value="worldkit.swf" name="movie"> 
<param value="high" name="quality">
<param value="#000000" name="bgcolor">

<embed pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" swliveconnect="true" align="" name="worldkit" height="350" width="700" bgcolor="#000000" quality="high" src="worldkit.swf">
</object>

</td><td valign="top">

<center><span class="sponsor">Tags</span></center>
<div id="legend" class="legend">
</div>
<br><br>
<center><span class="sponsor"><a href="javascript:vis('about')">Please contribute!</a></span></center>
<div style="font-size:12px; visibility:hidden; display:none;" class="legend" id="about">
To annotate, press "i" and click the location on the map. Fill in as much as you like, nothing is required. 
<p/>
<a href="http://brainoff.com/worldkit/doc/geowiki.php">Documentation</a> is available.
<p/>
Comments and suggestions can be sent <a href="http://brainoff.com/worldkit/contact.php">here</a>.
</div>
<br>
<center>
<a href="rss.xml"><img border="0" src="xml.gif"></a>
</center>
<br>
<center>
<a href="http://brainoff.com/worldkit/"><img border="0" src="http://www.brainoff.com/worldkit/poweredbyworldkit.jpg">
</center>
</td>

</tr></table>

<div id="divAnnotate" style="visibility:hidden; display:none;">
<a name="form"></a><form onsubmit="annotate();return false;" onReset="hideform(); return false;" name="formAnnotate">
<table>
<tr><td>url</td><td><input name="url" size="80"></td></tr>
<tr><td>title</td><td><input name="title" size="80"></td></tr>
<tr><td>description</td><td><input name="description" size="80"></td></tr>
<tr><td>image url</td><td><input name="imgurl" size="80"></td></tr>
<tr><td>lat</td><td><input name="lat"></td></tr>
<tr><td>long</td><td><input name="long"></td></tr>
<tr><td>tags</td><td><input name="tags" size="80"></td></tr>
<tr><td>user</td><td><input name="user" size="80"></td></tr>
<tr><td colspan=2><input name="submit" value="Submit" type="submit"><input name="cancel" type="reset" value="Cancel"></td></tr>
</table>
</form>
</div>

</body>
</html>
