function parseArgs(args) {
  var AO = new Object();
  var AA = args.split("&");
  var TA = new Array();
  for (var i=0; i<AA.length; i++) {
    TA = AA[ i ].split("=");
    AO[ TA[0] ] = unescape( TA[1] );
  }
  return AO;
}
function worldkitCallback(args) {
  /* make sure the form is visible */
  document.getElementById("divAnnotate").style.visibility = "visible";
  document.getElementById("divAnnotate").style.display = "block";
  document.location = '#form';
  var ArgObject = parseArgs(args);
  document.forms["formAnnotate"].elements["lat"].value = ArgObject["lat"];
  document.forms["formAnnotate"].elements["long"].value = ArgObject["long"];
}


function annotate() {
	jsrsPost = true;
	var form = document.forms['formAnnotate'];
	jsrsExecute("annotate.rs.php", annotateCallback, "annotate", 
		Array(form['url'].value, form['title'].value, form['description'].value, form['imgurl'].value, form['tags'].value, form['lat'].value, form['long'].value, form['user'].value) );
}
function hideform() {
	var form = document.forms['formAnnotate'];
	form['url'].value = '';
	form['title'].value = '';
	form['description'].value = '';
	form['imgurl'].value = '';
	form['tags'].value = '';
	form['lat'].value = '';
	form['long'].value = '';
	form['user'].value = '';
	form = document.getElementById('divAnnotate');
	form.style.visibility = "hidden";
	form.style.display = "none";
}
function annotateCallback( returnstring ) {
	if (returnstring == "success") {
		/* reload the RSS feed */
		document.worldkit.SetVariable("JLoadComm","updateurl");
		gettags();
		hideform();
	}		
}

function intervalUpdate() {
	document.worldkit.SetVariable("JLoadComm","updateurl");
	gettags();
}

function doPassVar(args) {
	document.worldkit.SetVariable("JSubComm",args);
}
function tagclick(tag) {
	if (typeof prevtag != "undefined") {
		if (prevtag == tag) {
			document.worldkit.SetVariable("JSubComm",prevtag);
			return;
		} else {
			document.worldkit.SetVariable("JActComm",prevtag);
		}
	}
	prevtag = tag;
	document.worldkit.SetVariable("JActComm",tag);
}

function gettags() {
	jsrsPost = true;
	jsrsExecute("gettags.rs.php", gettagsCallback, "gettags");
}
function gettagsCallback( returnstring ) {
	document.getElementById('legend').innerHTML = returnstring;
}


function loadActions() {
	gettags();
	setInterval("intervalUpdate();", 300000);
	document.worldkit.focus();
}


function doZoom(args) {
	document.worldkit.SetVariable("JZoomComm",args);
}

function vis(args) {
	var e = document.getElementById(args);
	if (e.style.visibility == "hidden") {
		e.style.visibility = "visible";
		e.style.display = "block";
	} else {
		e.style.visibility = "hidden";
		e.style.display = "none";
	}
}
