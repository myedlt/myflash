<?php 
require("jsrsServer.php.inc");
jsrsDispatch( "annotate");

function buildtags($newtags) {
	$lines = file("./tags.count","r");
	foreach ($lines as $line) {
		$line = rtrim($line);
		$tmp = split("\t", $line);
		$tags[ $tmp[0] ] = $tmp[1];
	}

	$tmp = split(" ", $newtags);
	foreach ($tmp as $tag) {
		$tags[ $tag ] += 1;
	}

	$maxcount = 0;

	$handle = fopen("./tags.count","w");
	foreach (array_keys($tags) as $tag) {
		fwrite($handle, $tag . "\t" . $tags[ $tag ] . "\n");
		if ($tags[ $tag ] > $maxcount) {
			$maxcount = $tags[ $tag ];
		}	
	}
	fclose($handle);

	$minsize = 10;
	$maxsize = 20;

	$sorted = array_keys($tags); sort($sorted);

	$handle = fopen("./tags","w");
	foreach ($sorted as $tag) {
		$size = ($maxsize-$minsize) * $tags[$tag] / $maxcount + $minsize;
		fwrite($handle, "<a href=\"javascript:tagclick('" . $tag . "')\" style=\"font-size: ". $size . "px;\">" . $tag . "</a> ");
	}
	fclose($handle);
} 

function annotate($url,$title,$description,$imgurl,$tags,$lat,$long,$user) {
	$handle = fopen("./rss.xml","r");
	$contents = fread($handle, filesize("./rss.xml"));
	fclose($handle);

	$cat = "";
	$tmp = split(" ", $tags);
	foreach($tmp as $tag) {
		$cat .= "<category>" . $tag . "</category>";
	}

	$imgtag = "";
	if (strlen($imgurl) > 0) {
		$imgtag = "<photo:thumbnail>" . $imgurl . "</photo:thumbnail>";
	}

	$newitem = "<item><title>$title</title><link>$url</link><description><![CDATA[" . $description . "<br><i>by: $user; tags: $tags</i>]]></description><author>$user</author><geo:lat>$lat</geo:lat><geo:long>$long</geo:long>" . $cat . $imgtag . "</item>\n\t\t";

	$pos = strpos($contents, '<item>');
	$newcontents = substr_replace($contents, $newitem, $pos, 0);

	$handle = fopen("./rss.xml","w");
	fwrite($handle, $newcontents);
	fclose($handle);

	buildtags($tags);

	return ("success");
} 

