<?php 
require("jsrsServer.php.inc");
jsrsDispatch( "gettags" );

function gettags() {
	return file_get_contents('./tags');
} 

